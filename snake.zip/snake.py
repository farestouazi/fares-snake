#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#----------------------------------------------------#
#----------------------SNAKE-------------------------#
#----------------------------------------------------#
#-----------------------De :-------------------------#
#------------------Fares   Touazi--------------------#
#----------------------------------------------------#
#-------------------Janvier 2025---------------------#
#----------------------------------------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

######################################################
######################################################
######################################################

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#--------------------- IMPORTS ----------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

import fltk
import time
import random
import pyautogui

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#--------------------INIT FENETRE--------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

def TAILLE_IDEALE() :
    SIZES_SCREEN = [12,13,14,15,16,17,18,19,20,21,22,23,24,25]
    for SIZE in SIZES_SCREEN :
        if not pyautogui.onScreen(SIZE*75, SIZE*40) :
            return SIZES_SCREEN[SIZES_SCREEN.index(SIZE)-1]

TAILLE_CASE = TAILLE_IDEALE()

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#-------------------- CONSTANTES --------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

LARGEUR_PLATEAU = 40
HAUTEUR_PLATEAU = 30

CARTE1 = [
    (0, 4), (1, 4), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4), (7, 4), (8, 4), (9, 4),
    (39, 4), (38, 4), (37, 4), (36, 4), (35, 4), (34, 4), (33, 4), (32, 4), (31, 4), (30, 4),
    (29, 4), (28, 4), (27, 4), (26, 4), (25, 4), (24, 4), (23, 4), (22, 4), (21, 4), (20, 4),
    (19, 4), (18, 4), (17, 4), (16, 4), (15, 4), (14, 4), (13, 4), (12, 4), (11, 4), (10, 4),
    (0, 33), (1, 33), (2, 33), (3, 33), (4, 33), (5, 33), (6, 33), (7, 33), (8, 33), (9, 33),
    (39, 33), (38, 33), (37, 33), (36, 33), (35, 33), (34, 33), (33, 33), (32, 33), (31, 33), (30, 33),
    (29, 33), (28, 33), (27, 33), (26, 33), (25, 33), (24, 33), (23, 33), (22, 33), (21, 33), (20, 33),
    (19, 33), (18, 33), (17, 33), (16, 33), (15, 33), (14, 33), (13, 33), (12, 33), (11, 33), (10, 33),
    (0, 5), (0, 6), (0, 7), (0, 8), (0, 9), (0, 10), (0, 11), (0, 12), (0, 13), (0, 14),
    (0, 15), (0, 16), (0, 17), (0, 18), (0, 19), (0, 20), (0, 21), (0, 22), (0, 23), (0, 24),
    (0, 25), (0, 26), (0, 27), (0, 28),
    (39, 5), (39, 6), (39, 7), (39, 8), (39, 9), (39, 10), (39, 11), (39, 12), (39, 13), (39, 14),
    (39, 15), (39, 16), (39, 17), (39, 18), (39, 19), (39, 20), (39, 21), (39, 22), (39, 23), (39, 24),
    (39, 25), (39, 26), (39, 27), (39, 28),
    (10, 14), (11, 14), (12, 14), (13, 14), (14, 14), (15, 14), (16, 14), (17, 14), (18, 14), (19, 14),
    (20, 14), (21, 14), (22, 14), (23, 14), (24, 14), (25, 14), (26, 14), (27, 14), (28, 14), (29, 14),
    (10, 9), (11, 9), (12, 9), (13, 9), (14, 9), (15, 9), (16, 9), (17, 9), (18, 9), (19, 9),
    (19, 10), (19, 11), (19, 12), (18, 12), (17, 12), (16, 12), (15, 12), (14, 12), (13, 12), (12, 12),
    (25, 9), (26, 9), (27, 9), (28, 9), (29, 9), (30, 9), (31, 9), (32, 9), (33, 9), (34, 9),
    (15, 19), (16, 19), (17, 19), (18, 19), (19, 19), (20, 19), (21, 19), (22, 19),
    (30, 19), (31, 19), (32, 19), (33, 19), (34, 19), (35, 19),
    (15, 24), (16, 24), (17, 24), (18, 24), (19, 24), (20, 24), (21, 24), (22, 24),
    (25, 24), (26, 24), (27, 24), (28, 24), (29, 24), (30, 24),
    (15, 29), (16, 29), (17, 29), (18, 29), (19, 29), (20, 29), (21, 29), (22, 29),
    (25, 29), (26, 29), (27, 29), (28, 29), (29, 29), (30, 29)
    ]

CARTE2 = [
    (0, 4), (1, 4), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4), (7, 4), (8, 4), (9, 4),
    (39, 8), (39, 9), (39, 10), (39, 11), (39, 12), (39, 13), (39, 14), (39, 15), (39, 16), (39, 17),
    (39, 33), (39, 34), (39, 35), (39, 36), (39, 37), (39, 38), (39, 39), (39, 40), (39, 41), (39, 42),
    (0, 33), (0, 34), (0, 35), (0, 36), (0, 37), (0, 38), (0, 39), (0, 40), (0, 41), (0, 42),
    (10, 14), (10, 15), (10, 16), (11, 16), (13, 16), (13, 15), (13, 14), (12, 14),
    (21, 19), (22, 19), (21, 20), (20, 20), (19, 20), (18, 20), (18, 19),
    (25, 14), (25, 15), (25, 16), (26, 16), (26, 15), (26, 14),
    (5, 9), (6, 9), (7, 9), (9, 9), (9, 10), (9, 11), (8, 11), (7, 11),
    (5, 11), (5, 12), (5, 13), (6, 13), (7, 13), (9, 13),
    (15, 8), (15, 9), (15, 10), (15, 11), (15, 12), (15, 13),
    (24, 8), (24, 9), (24, 10), (24, 11), (24, 12), (24, 13),
    (10, 24), (11, 24), (12, 24), (13, 24), (14, 24), (15, 24), (16, 24), (17, 24), (18, 24), (19, 24),
    (30, 14), (30, 15), (30, 16), (31, 16), (32, 16), (33, 16), (34, 16), (35, 16), (36, 16), (37, 16),
    (30, 17), (30, 18), (32, 18), (33, 18), (34, 18), (35, 18), (36, 18), (37, 18),
    (17, 9), (17, 10), (18, 10), (18, 9), (19, 9), (19, 10),
    (20, 14), (21, 14), (22, 14), (23, 14), (24, 14), (25, 14),
    (28, 19), (28, 20), (28, 21), (28, 22), (28, 23), (28, 24), 
    (10, 29), (11, 29), (12, 29), (13, 29), (14, 29), (15, 29), 
    (35, 22), (35, 23), (35, 24), (35, 25), (35, 26),
    (12, 29), (13, 29), (14, 29), (15, 29), (16, 29), (17, 29),
    (19, 29), (20, 29), (21, 29), (22, 29), (23, 29), (24, 29)
    ]

CARTE3 = [
    (0, 4), (1, 4), (2, 4), (3, 4), (4, 4), (5, 4), (6, 4), (7, 4), (8, 4), (9, 4), 
    (14, 4), (15, 4), (16, 4), (17, 4), (18, 4), (19, 4), (20, 4), (21, 4), (22, 4), 
    (23, 4), (24, 4), (25, 4), (26, 4), (27, 4), (29, 4), (30, 4), (31, 4), (32, 4), 
    (33, 4), (34, 4), (36, 4), (37, 4), (38, 4), (39, 4), (32, 5), (32, 6), (32, 7), 
    (32, 8), (0, 5), (39, 5), (0, 6), (39, 6), (0, 7), (39, 7), (0, 8), (39, 8), (0, 9), 
    (39, 9), (0, 10), (39, 10), (0, 11), (39, 11), (0, 12), (39, 12), (0, 20), (39, 20), 
    (0, 21), (39, 21), (0, 22), (39, 22), (0, 23), (39, 23), (0, 24), (39, 24), (0, 25), 
    (39, 25), (0, 26), (39, 26), (0, 27), (39, 27), (0, 28), (39, 28), (0, 29), (39, 29), 
    (5, 9), (5, 10), (5, 11), (6, 11), (7, 11), (8, 11), (9, 11), (15, 24), (16, 24), 
    (17, 24), (18, 24), (19, 24), (20, 24), (20, 25), (20, 26), (9, 12), (26, 13), (29, 13), 
    (32, 13), (26, 14), (27, 14), (29, 14), (31, 14), (32, 14), (29, 15), (26, 16), (27, 16), 
    (29, 16), (31, 16), (32, 16), (26, 17), (29, 17), (32, 17), (26, 25), (26, 26), (26, 27), 
    (26, 28), (26, 29), (15, 9), (16, 9), (17, 9), (18, 9), (15, 11), (16, 11), (17, 11), 
    (18, 11), (15, 12), (15, 13), (24, 24), (25, 24), (26, 24), (27, 24), (28, 24), (13, 21), 
    (14, 21), (15, 20), (16, 19), (14, 22), (14, 23), (14, 24), (6, 24), (7, 25), (8, 26), 
    (9, 27), (9, 28), (20, 17), (21, 17), (22, 17), (24, 24), (25, 24), (26, 24), (27, 24), 
    (28, 24), (26, 25), (26, 26), (26, 27), (26, 28), (26, 29), (34, 27), (35, 28), (36, 29), 
    (37, 29), (38, 29), (20, 32), (20, 31), (20, 30), (0,33), (1,33), (2,33), (3,33), 
    (4,33), (5,33), (6,33), (7,33), (8,33), (9,33), (14,33), (15,33), (16,33), (17,33), 
    (18,33), (19,33), (20,33), (21,33), (22,33), (23,33), (24,33), (25,33), (26,33), 
    (27,33), (29,33), (30,33), (31,33), (32,33), (33,33), (34,33), (36,33), (37,33), 
    (38,33), (39,33)
    ]

SERPENT1 = [[(2, 24), (2, 25), (2, 26), (2, 27)],
            [(37, 24), (37, 25), (37, 26), (37, 27)]]

SERPENT2 = [[(27, 14), (27, 15), (27, 16), (27, 17)],
            [(29, 14), (29, 15), (29, 16), (29, 17)]]

SERPENT3 = [[(10, 14), (10, 15), (10, 16), (10, 17)],
            [(12, 14), (12, 15), (12, 16), (12, 17)]]

CARTES = [CARTE1,CARTE2,CARTE3]
SERPENTS = [SERPENT1,SERPENT2,SERPENT3]

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#--------------------- FONCTIONS --------------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

def case_vers_pixel(case):
    """
    Reçoit les coordonnées d'une case du plateau sous la forme d'un couple
    d'entiers (colonne, ligne) et renvoie les coordonnées du centre de cette
    case sous la forme d'un couple de flottants (abscisse, ordonnée). 
    
    Ce calcul prend en compte la taille de chaque case, donnée par la variable
    globale `TAILLE_CASE`.
    
    >>> TAILLE_CASE = 10
    >>> case_vers_pixel((4, 6))
    (45.0, 65.0)
    """
    i, j = case
    return (i + .5) * TAILLE_CASE, (j + .5) * TAILLE_CASE


def affiche_pommes(pommes):
    """
    Dessine une pomme dans chaque case désignée par la liste de couples
    d'entiers `pommes`. Pas de valeur de retour.
    
    """
    i = 0
    while i < len(pommes):
        pomme = pommes[i]
        x, y = case_vers_pixel(pomme)
        fltk.cercle(x, y, TAILLE_CASE/2,
                    couleur='darkred', remplissage='red')
        fltk.rectangle(x-2, y-TAILLE_CASE*.4, x+2, y-TAILLE_CASE*.7,
                       couleur='darkgreen', remplissage='darkgreen')
        i += 1


def affiche_serpent(serpent, direction, couleur_corps, couleur_tete):
    """
    Dessine le serpent dont les éléments du corps sont désignés par la liste de
    couples d'entiers `serpent` (le premier élément de la liste désigne la tête
    du serpent). Pas de valeur de retour.
    
    """
    for pixel in serpent:
        x, y = case_vers_pixel(pixel)
        if serpent.index(pixel) == 0:
            fltk.cercle(x, y, TAILLE_CASE/2 + 1, couleur=couleur_tete, remplissage=couleur_tete)
        else:  # Corps du serpent
            fltk.cercle(x, y, TAILLE_CASE/2 + 1, couleur=couleur_corps, remplissage=couleur_corps)
        
def affiche_murs(murs):
    """
    Dessine les murs dont les éléments sont désignés par la liste de
    couples d'entiers `murs`. Pas de valeur de retour.
    
    """
    for mur in murs :
        x, y = case_vers_pixel(mur)
        fltk.rectangle(x-TAILLE_CASE/2, y-TAILLE_CASE/2, x+TAILLE_CASE/2, y+TAILLE_CASE/2, '#ABABAB', '#ABABAB')

def change_direction(direction, touche=None, joueur=1):
    """
    Renvoie le vecteur unitaire indiquant la direction correspondant à la touche
    pressée par l'utilisateur. Les valeurs de retour possibles sont
    '(0, 1)', '(1, 0)', '(0, -1)' et '(-1, 0)'.
    
    """
    if joueur == 1:
        if touche == 'Up' and direction != (0, 1):
            return (0, -1)
        elif touche == 'Down' and direction != (0, -1):
            return (0, 1)
        elif touche == 'Right' and direction != (-1, 0):
            return (1, 0)
        elif touche == 'Left' and direction != (1, 0):
            return (-1, 0)
    elif joueur == 2:
        if touche == 'w' and direction != (0, 1):
            return (0, -1)
        elif touche == 's' and direction != (0, -1):
            return (0, 1)
        elif touche == 'd' and direction != (-1, 0):
            return (1, 0)
        elif touche == 'a' and direction != (1, 0):
            return (-1, 0)
    return direction

def bouge_serpent(serpent, direction):
    """
    Déplace le serpent dans la direction donnée
    si le serpent sort par un bord, il réapparaît de l'autre côté.
    
    param :
        serpent : (list) liste des positions du corps du serpent
        direction : (tuple) direction de deplacement du serpent
        
    return :
        (list) nouvelle liste des positions du serpent apres le deplacement
    """
    nv_serpent = (serpent[0][0] + direction[0], serpent[0][1] + direction[1])
    if nv_serpent[0] >= LARGEUR_PLATEAU:
        nv_serpent = (0, nv_serpent[1])
    elif nv_serpent[0] < 0:
        nv_serpent = (LARGEUR_PLATEAU - 1, nv_serpent[1])
    if nv_serpent[1] >= HAUTEUR_PLATEAU+4:
        nv_serpent = (nv_serpent[0], 0)
    elif nv_serpent[1] < 4:
        nv_serpent = (nv_serpent[0], (HAUTEUR_PLATEAU+4) - 1)
    serpent = [nv_serpent] + serpent[:-1]
    return serpent

def mange_pommes(serpent1, serpent2, pommes, murs, framerate):
    """
    Manger une pomme et augmenter la vitesse du jeu
    param :
        serpent : (list) corps du serpent
        pommes  : (list) liste des pommes sur le plateau
        murs    : (list) liste des obstacles
        framerate : (int or float) framerate actuelle
    return :
        int or float : nouveau framerate
    """
    if serpent1[0] in pommes:
        pommes.remove(serpent1[0])
        serpent1.append(serpent1[-1])
        pommes.append(poser_pommes(serpent1, serpent2, murs))
        return pommes, framerate * .9982
    elif serpent2[0] in pommes:
        pommes.remove(serpent2[0])
        serpent2.append(serpent2[-1])
        pommes.append(poser_pommes(serpent1, serpent2, murs))
        return pommes, framerate * .9982
    return pommes, framerate

def poser_pommes(serpent1, serpent2, murs):
    """
    Place une pomme à un endroit aléatoire
    si l'endroit n'est pas occupé par un mur ou le corps du serpent.
    
    param :
        serpent1 : (list) corps du serpent1
        serpent2 : (list) corps du serpent2
        murs    : (list) liste des obstacles
    return :
        pomme : (tuple) cordonnées de la nouvelle pomme posée
    """
    pomme = random.randint(1, LARGEUR_PLATEAU - 2), random.randint(5, HAUTEUR_PLATEAU + 3)
    while pomme in serpent1 or pomme in serpent2 or pomme in murs :
        pomme = random.randint(1, LARGEUR_PLATEAU - 2), random.randint(1, HAUTEUR_PLATEAU - 2)
    return pomme

def detecter_collision(serpent) :
    """
    Détecter la collision de la tête du serpent avec son corps
    param :
        serpent : (list) corps du serpent
    return :
        (bool) True si une collision est detectée, False sinon
    """
    serpent_sans_tete = []
    for _ in range(1,len(serpent)) :
        serpent_sans_tete.append(serpent[_])
    if serpent[0] in serpent_sans_tete : 
        return True
    return False

def detecter_collision_serpent(nb_joueurs,serpent1,serpent2) :
    """
    Détecter la collision de la tête du serpent avec le corps de l'autre serpent
    param :
        nb_joueurs : (int) 1 or 2
        serpent1 : (list) corps du premier  serpent
        serpent2 : (list) corps du deuxieme serpent
    return :
        (bool) True si une collision est detectée, False sinon
    """
    if nb_joueurs == 2 :
        serpent_sans_tete = []
        for _ in range(1,len(serpent2)) :
            serpent_sans_tete.append(serpent2[_])
        if serpent1[0] in serpent_sans_tete : 
            return True
        return False
    else :
        return False
        
def detecter_collision_avec_mur(serpent,murs) :
    """
    Détecter la collision de la tête du serpent avec un obstacle
    param :
        serpent : (list) corps du serpent
        murs    : (list) liste des obstacles
    return :
        (bool) True si une collision est detectée, False sinon
    """
    if serpent[0] in murs :
        return True
    return False

def partie(nb_joueurs,carte,serpent,fram):
    """
    Code de la partie
    param :
        nb_joueurs : (int)
        carte : (list)
        serpent : (list)
        fram : (int)
    return : (bool) True or False
    
    """
    serpent1 = serpent[0]
    serpent2 = serpent[1]
    
    murs = carte
    
    if nb_joueurs == 2 :
        pommes = [(poser_pommes(serpent1, serpent2, murs)) for i in range(3)]
    else :
        pommes = [(poser_pommes(serpent1, [], murs)) for i in range(3)]
    jouer = True
    direction1 = (0, -1)
    if nb_joueurs == 2 :
        direction2 = (0, -1)
    framerate = fram
    score1 = score2 = 0

    while jouer :
        if not detecter_collision_avec_mur(serpent1, murs) and not detecter_collision(serpent1) and not detecter_collision_avec_mur(serpent2, murs) and not detecter_collision(serpent2) and not detecter_collision_serpent(nb_joueurs,serpent2,serpent1) and not detecter_collision_serpent(nb_joueurs,serpent1,serpent2):
            fltk.efface_tout()
            fltk.rectangle(0,0,TAILLE_CASE * LARGEUR_PLATEAU, TAILLE_CASE * 4, 'black', 'black')
            fltk.rectangle(0,TAILLE_CASE * 4,TAILLE_CASE * LARGEUR_PLATEAU, TAILLE_CASE * (HAUTEUR_PLATEAU+4), 'black', '#121212')
            fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2+TAILLE_CASE*2,TAILLE_CASE *2, "Score (1) : ", couleur="blue",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/40))
            fltk.rectangle(TAILLE_CASE * 2,TAILLE_CASE * 2,TAILLE_CASE * 8, TAILLE_CASE * 3, 'blue')
            fltk.rectangle(TAILLE_CASE * 4,TAILLE_CASE * 1,TAILLE_CASE * 6, TAILLE_CASE * 3, 'blue')
            fltk.texte(TAILLE_CASE*3,TAILLE_CASE*2.5, "Left", couleur="blue",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))
            fltk.texte(TAILLE_CASE*5,TAILLE_CASE*2.5, "Down", couleur="blue",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))
            fltk.texte(TAILLE_CASE*7,TAILLE_CASE*2.5, "Right", couleur="blue",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))
            fltk.texte(TAILLE_CASE*5,TAILLE_CASE*1.5, "Up", couleur="blue",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))

            if nb_joueurs == 2 :
                fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2+TAILLE_CASE*10,TAILLE_CASE *2, "Score (2) : ", couleur="orange",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/40))
                fltk.rectangle(TAILLE_CASE * 10,TAILLE_CASE * 2,TAILLE_CASE * 16, TAILLE_CASE * 3, 'orange')
                fltk.rectangle(TAILLE_CASE * 12,TAILLE_CASE * 1,TAILLE_CASE * 14, TAILLE_CASE * 3, 'orange')
                fltk.texte(TAILLE_CASE*11,TAILLE_CASE*2.5, "Q", couleur="orange",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))
                fltk.texte(TAILLE_CASE*13,TAILLE_CASE*2.5, "S", couleur="orange",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))
                fltk.texte(TAILLE_CASE*15,TAILLE_CASE*2.5, "D", couleur="orange",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))
                fltk.texte(TAILLE_CASE*13,TAILLE_CASE*1.5, "Z", couleur="orange",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/90))
            fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2+TAILLE_CASE*5,TAILLE_CASE *2, str(score1), couleur="blue",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/40))
            if nb_joueurs == 2 :
                fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2+TAILLE_CASE*13,TAILLE_CASE *2, str(score2), couleur="orange",ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/40))
            affiche_pommes(pommes)
            affiche_serpent(serpent1, direction1, "darkblue", "blue")
            if nb_joueurs == 2 :
                affiche_serpent(serpent2, direction2, "purple", "orange")
            affiche_murs(murs)
            fltk.mise_a_jour()

            event = fltk.donne_ev()
            type_event = fltk.type_ev(event)
            
            if type_event == 'Quitte':
                jouer = False
                break
            elif type_event == 'Touche':
                direction1 = change_direction(direction1, fltk.touche(event), joueur=1)
                if nb_joueurs == 2 :
                    direction2 = change_direction(direction2, fltk.touche(event), joueur=2)
            
            serpent1 = bouge_serpent(serpent1, direction1)            
            if nb_joueurs == 2 :
                serpent2 = bouge_serpent(serpent2, direction2)
            
            score1 = len(serpent1) - 4
            if nb_joueurs == 2 :
                score2 = len(serpent2) - 4

            pommes, framerate = mange_pommes(serpent1, serpent2, pommes, murs, framerate)
            time.sleep(framerate / 10)
            
        else :
            fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-7*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2-7*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+7*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+7*TAILLE_CASE, '#FFFFFF', '#000000')
            if nb_joueurs == 2 :
                if detecter_collision_avec_mur(serpent1, murs) or detecter_collision(serpent1) or detecter_collision_serpent(serpent1,serpent2):
                    texte = "Joueur 2 Gagne"
                    couleur = "orange"
                if detecter_collision_avec_mur(serpent2, murs) or detecter_collision(serpent2) or detecter_collision_serpent(serpent2,serpent1):
                    texte = "Joueur 1 Gagne"
                    couleur = "blue"
                fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2,(TAILLE_CASE * HAUTEUR_PLATEAU)/2-5.5*TAILLE_CASE,texte,couleur=couleur, ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/36))
            else :
                fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2,(TAILLE_CASE * HAUTEUR_PLATEAU)/2-5.5*TAILLE_CASE, "Défaite !",couleur="white", ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/36))
            
            fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+0*TAILLE_CASE, '#FFFFFF', '#000000')
            fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2,(TAILLE_CASE * HAUTEUR_PLATEAU)/2-2*TAILLE_CASE, "Rejouer", couleur="white", ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/40))
            
            fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+1*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+5*TAILLE_CASE, '#FFFFFF', '#000000')
            fltk.texte((TAILLE_CASE * LARGEUR_PLATEAU)/2,(TAILLE_CASE * HAUTEUR_PLATEAU)/2+3*TAILLE_CASE, "Quitter", couleur="white", ancrage="center",taille=int((TAILLE_CASE * HAUTEUR_PLATEAU)/40))
            
            event = fltk.attend_ev()
            type_event = fltk.type_ev(event)

            if type_event == "ClicGauche":
                if LARGEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2+4*TAILLE_CASE :
                    if HAUTEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE < fltk.ordonnee_souris() < HAUTEUR_PLATEAU*TAILLE_CASE/2+0*TAILLE_CASE :
                        return True
                    elif HAUTEUR_PLATEAU*TAILLE_CASE/2+1*TAILLE_CASE < fltk.ordonnee_souris() < HAUTEUR_PLATEAU*TAILLE_CASE/2+5*TAILLE_CASE :
                        return False
            elif type_event == "Quitter":
                return False
    return False

def obtenir_nb_joueurs() :
    """
    Afficher un menu permetant de choisir le mode du jeu : Solo ( 1 joueur ) Multijoueur ( 2 joueur )
    return : (int) 1 or 2
    
    """
    fltk.efface_tout()
    fltk.rectangle(0,0,TAILLE_CASE * LARGEUR_PLATEAU, TAILLE_CASE * (4+HAUTEUR_PLATEAU),'#151515','#151515')
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2, TAILLE_CASE * HAUTEUR_PLATEAU/2-TAILLE_CASE*8,'SNAKE',couleur="lightgreen",ancrage='center',taille=int(TAILLE_CASE*1.7))
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2, TAILLE_CASE * HAUTEUR_PLATEAU/2-TAILLE_CASE*5,'Jouer :',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.4))
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-12*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2-2*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2- 2*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+2*TAILLE_CASE, '#FFFFFF', '#000000')
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2+ 2*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2-2*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+12*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+2*TAILLE_CASE, '#FFFFFF', '#000000')
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2-7*TAILLE_CASE, TAILLE_CASE * HAUTEUR_PLATEAU/2,'Solo',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2+7*TAILLE_CASE, TAILLE_CASE * HAUTEUR_PLATEAU/2,'Multijoueur',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    event = fltk.attend_ev()
    type_event = fltk.type_ev(event)
    
    if type_event == 'Quitte':
        fltk.ferme_fenetre()
        quit()
    
    elif type_event == "ClicGauche":
        if HAUTEUR_PLATEAU*TAILLE_CASE/2-2*TAILLE_CASE < fltk.ordonnee_souris() < HAUTEUR_PLATEAU*TAILLE_CASE/2+2*TAILLE_CASE :
            if LARGEUR_PLATEAU*TAILLE_CASE/2-17*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2-2*TAILLE_CASE :
                return 1
            elif LARGEUR_PLATEAU*TAILLE_CASE/2+2*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2+12*TAILLE_CASE :
                return 2

def obtenir_map_jeu() :
    """
    Afficher un menu permetant de choisir la carte
    return : (int) 0, 1 or 2
    
    """
    fltk.efface_tout()
    fltk.rectangle(0,0,TAILLE_CASE * LARGEUR_PLATEAU, TAILLE_CASE * (4+HAUTEUR_PLATEAU),'#151515','#151515')
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2, TAILLE_CASE * HAUTEUR_PLATEAU/2-TAILLE_CASE*8,'Carte :',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.5))
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-16*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2-8*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+12*TAILLE_CASE, '#FFFFFF', '#000000')
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+12*TAILLE_CASE, '#FFFFFF', '#000000')
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+16*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+12*TAILLE_CASE, '#FFFFFF', '#000000')
    
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2-12*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+10*TAILLE_CASE,'Map 1',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2, HAUTEUR_PLATEAU*TAILLE_CASE/2+10*TAILLE_CASE,'Map 2',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2+12*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+10*TAILLE_CASE,'Map 3',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    
    event = fltk.attend_ev()
    type_event = fltk.type_ev(event)
    
    if type_event == 'Quitte':
        fltk.ferme_fenetre()
        quit()
    
    elif type_event == "ClicGauche":
        if HAUTEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE < fltk.ordonnee_souris() < HAUTEUR_PLATEAU*TAILLE_CASE/2+12*TAILLE_CASE :
            if LARGEUR_PLATEAU*TAILLE_CASE/2-16*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2-8*TAILLE_CASE :
                return 0
            elif LARGEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2+4*TAILLE_CASE :
                return 1
            elif LARGEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2+16*TAILLE_CASE :
                return 2

def obtenir_difficulte() :
    """
    Afficher un menu permetant de choisir la difficulte
    return : (int) framerate
    
    """
    fltk.efface_tout()
    fltk.rectangle(0,0,TAILLE_CASE * LARGEUR_PLATEAU, TAILLE_CASE * (4+HAUTEUR_PLATEAU),'#151515','#151515')
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2, TAILLE_CASE * HAUTEUR_PLATEAU/2-TAILLE_CASE*8,'Difficulte :',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.5))
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-16*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+5*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2-8*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+9*TAILLE_CASE, '#FFFFFF', '#000000')
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+5*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+4*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+9*TAILLE_CASE, '#FFFFFF', '#000000')
    fltk.rectangle(LARGEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+5*TAILLE_CASE, LARGEUR_PLATEAU*TAILLE_CASE/2+16*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+9*TAILLE_CASE, '#FFFFFF', '#000000')
    
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2-12*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+7*TAILLE_CASE,'Facile',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2, HAUTEUR_PLATEAU*TAILLE_CASE/2+7*TAILLE_CASE,'Moyen',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    fltk.texte(TAILLE_CASE * LARGEUR_PLATEAU/2+12*TAILLE_CASE, HAUTEUR_PLATEAU*TAILLE_CASE/2+7*TAILLE_CASE,'Difficile',couleur="white",ancrage='center',taille=int(TAILLE_CASE*1.1))
    
    event = fltk.attend_ev()
    type_event = fltk.type_ev(event)
    
    if type_event == 'Quitte':
        fltk.ferme_fenetre()
        quit()
    
    elif type_event == "ClicGauche":
        if HAUTEUR_PLATEAU*TAILLE_CASE/2+5*TAILLE_CASE < fltk.ordonnee_souris() < HAUTEUR_PLATEAU*TAILLE_CASE/2+9*TAILLE_CASE :
            if LARGEUR_PLATEAU*TAILLE_CASE/2-16*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2-8*TAILLE_CASE :
                return 5
            elif LARGEUR_PLATEAU*TAILLE_CASE/2-4*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2+4*TAILLE_CASE :
                return 1.5
            elif LARGEUR_PLATEAU*TAILLE_CASE/2+8*TAILLE_CASE < fltk.abscisse_souris() < LARGEUR_PLATEAU*TAILLE_CASE/2+16*TAILLE_CASE :
                return 0.4

def main() :
    """
    Fonction principale
    param : 0
    return : None
    
    """
    fltk.cree_fenetre(TAILLE_CASE * LARGEUR_PLATEAU, TAILLE_CASE * (4+HAUTEUR_PLATEAU))
    
    nb_joueurs = obtenir_nb_joueurs()
    selection = obtenir_map_jeu()
    framerate = obtenir_difficulte()
    
    carte = CARTES[selection]
    serpent = SERPENTS[selection]
    
    jouer = True
    while jouer:
        jouer = partie(nb_joueurs,carte,serpent,framerate)

#++++++++++++++++++++++++++++++++++++++++++++++++++++#
#--------------- PROGRAMME PRINCIPAL ----------------#
#++++++++++++++++++++++++++++++++++++++++++++++++++++#

if __name__ == "__main__":
    main()
    fltk.ferme_fenetre()
    print("Merci d'avoir joué !")
    quit()